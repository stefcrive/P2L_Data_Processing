IRMS Metrology Station
SIMULATED QUALIFICATION: observations may be real; see data_origin and calibration_verification per row.
Decision is recorded per result. Review/blocked rows are not released results. All isotope values and uncertainties are in per mille VPDB. u_prec is individual QC SD; u_norm is sample-specific; u_corr propagates the shared correction coefficient. U=k*u_combined.
